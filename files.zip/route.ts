// app/api/agent/publish/route.ts
// Nav Web Online — Autonomous Biomimicry Blog Agent
// Triggered by Vercel Cron OR manual POST request from admin UI
// POST body: { topic: string, pendingComments?: Comment[] }

import { NextRequest, NextResponse } from "next/server";
import Anthropic from "@anthropic-ai/sdk";
import { db } from "@/lib/firebase"; // your Firebase config
import { collection, addDoc, serverTimestamp } from "firebase/firestore";

const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

const AGENT_SYSTEM_PROMPT = `
You are the autonomous content agent for Nav Web Online, a biomimicry and innovation blog.
Your single job is to take a topic phrase and produce a publication-ready blog package:
a researched markdown article, media keywords, and a comment-moderation report
— delivered as one JSON object.

## Workflow

Run these phases in order:

### 1. Research
- Use web search to gather authoritative material on (a) the natural system and (b) the technological application it inspires.
- Prefer: peer-reviewed journals, AskNature, Biomimicry Institute, Nature, Science, IEEE Spectrum, MIT News.
- Collect at least 5 distinct sources with title + URL.

### 2. Write
Produce a markdown post of 1,500–2,000 words with this structure:
1. # <Compelling headline>
2. Introduction (150–200 words): hook with a vivid natural phenomenon
3. The Biological Inspiration (400–500 words): how the natural system works
4. From Biology to Engineering (400–500 words): translation to technology
5. The Technology Today (300–400 words): real products, labs, deployments
6. Limits, Trade-offs, and What's Next (200–300 words)
7. Conclusion (100–150 words)
8. Sources — numbered list [N] Title — URL

Tone: educational yet engaging. Cite every non-obvious claim. American English.

### 3. Identify Media Keywords
- 4–8 image search queries tagged subject: "natural_system" or "technology"
- 2–4 video search queries with purpose

### 4. Moderate Comments
- If pending comments provided, decide approve/flag with a reason for each.

### 5. Output
Return ONLY a single valid JSON object in this exact shape — no prose before or after:

{
  "post": {
    "title": "string",
    "slug": "string",
    "markdown": "string",
    "word_count": 0,
    "sources": [{ "title": "string", "url": "string" }]
  },
  "images": [
    { "subject": "natural_system", "search_query": "string", "alt_text": "string" }
  ],
  "videos": [
    { "keywords": "string", "purpose": "string" }
  ],
  "comments_moderated": [
    { "id": "string", "action": "approve", "reason": "string" }
  ],
  "notes": ["string"]
}

subject must be exactly "natural_system" or "technology".
action must be exactly "approve" or "flag".
DO NOT invent sources, statistics, or quotes.
`;

export async function POST(req: NextRequest) {
  // Verify cron secret so only Vercel Cron or your admin can trigger this
  const authHeader = req.headers.get("authorization");
  if (authHeader !== `Bearer ${process.env.CRON_SECRET}`) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { topic, pendingComments } = await req.json();

  if (!topic) {
    return NextResponse.json({ error: "topic is required" }, { status: 400 });
  }

  try {
    const userMessage = pendingComments?.length
      ? `Topic: ${topic}\n\nPending comments to moderate:\n${JSON.stringify(pendingComments, null, 2)}`
      : `Topic: ${topic}`;

    // Call Claude with web search tool enabled
    const response = await client.messages.create({
      model: "claude-sonnet-4-20250514",
      max_tokens: 8000,
      system: AGENT_SYSTEM_PROMPT,
      tools: [{ type: "web_search_20250305", name: "web_search" }],
      messages: [{ role: "user", content: userMessage }],
    });

    // Extract the JSON from Claude's response
    const textContent = response.content
      .filter((block) => block.type === "text")
      .map((block) => block.text)
      .join("");

    // Strip any accidental markdown fences
    const clean = textContent.replace(/```json|```/g, "").trim();
    const agentOutput = JSON.parse(clean);

    // Save post to Firestore
    const postsRef = collection(db, "posts");
    const docRef = await addDoc(postsRef, {
      title: agentOutput.post.title,
      slug: agentOutput.post.slug,
      markdown: agentOutput.post.markdown,
      wordCount: agentOutput.post.word_count,
      sources: agentOutput.post.sources,
      images: agentOutput.images,
      videos: agentOutput.videos,
      status: "published",
      createdAt: serverTimestamp(),
    });

    // Save moderated comments back to Firestore
    if (agentOutput.comments_moderated?.length) {
      const commentsRef = collection(db, "comments");
      for (const comment of agentOutput.comments_moderated) {
        await addDoc(commentsRef, {
          ...comment,
          processedAt: serverTimestamp(),
        });
      }
    }

    return NextResponse.json({
      success: true,
      postId: docRef.id,
      slug: agentOutput.post.slug,
      title: agentOutput.post.title,
      notes: agentOutput.notes,
    });
  } catch (err) {
    console.error("Agent error:", err);
    return NextResponse.json({ error: "Agent failed", detail: String(err) }, { status: 500 });
  }
}
