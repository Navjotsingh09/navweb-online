// app/api/cron/daily-post/route.ts
// This is what Vercel Cron actually hits daily.
// It picks a topic and calls the agent endpoint.

import { NextResponse } from "next/server";

// Rotate through topics — or replace with your own queue from Firestore
const TOPIC_QUEUE = [
  "biomimicry in architecture — how termite mounds inspire passive cooling",
  "how the lotus leaf inspired self-cleaning surfaces",
  "gecko-inspired adhesives and what comes next",
  "whale fin turbine blades — tubercle technology in wind energy",
  "spider silk and the future of sustainable materials",
  "how mangrove roots inspire flood-resistant infrastructure",
  "the Namib desert beetle and atmospheric water harvesting",
  "bird bones and aerospace lightweight structures",
  "how slime mould solved Tokyo's rail network",
  "bioluminescence and the future of sustainable lighting",
];

export async function GET(req: Request) {
  // Vercel Cron passes this header — verify it
  const authHeader = req.headers.get("authorization");
  if (authHeader !== `Bearer ${process.env.CRON_SECRET}`) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  // Pick topic based on day of year so it rotates
  const dayOfYear = Math.floor(
    (Date.now() - new Date(new Date().getFullYear(), 0, 0).getTime()) / 86400000
  );
  const topic = TOPIC_QUEUE[dayOfYear % TOPIC_QUEUE.length];

  // Call the agent
  const response = await fetch(`${process.env.NEXT_PUBLIC_BASE_URL}/api/agent/publish`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${process.env.CRON_SECRET}`,
    },
    body: JSON.stringify({ topic }),
  });

  const result = await response.json();
  return NextResponse.json(result);
}
